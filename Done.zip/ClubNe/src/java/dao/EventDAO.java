/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Events;

/**
 *
 * @author A
 */
public class EventDAO {

    private Connection conn;

    public EventDAO() {
        this.conn = DBContext.getInstance().getConnection();
    }

    public List<Events> getAllEvents() {
        List<Events> events = new ArrayList<>();
        String sql = "SELECT * FROM Events";
        try (PreparedStatement stmt = conn.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                events.add(mapResultSetToEvent1(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return events;
    }
    public List<Events> getEventsByClubId(int id) {
    List<Events> eventsList = new ArrayList<>();
    String query = "SELECT e.eventId, e.eventName, e.description, e.eventDate, " +
                   "e.location, e.clubId, c.clubName, e.image " +
                   "FROM Events e " +
                   "JOIN Clubs c ON e.clubId = c.clubId " +
                   "WHERE e.clubId = ?";

    try (PreparedStatement stmt = conn.prepareStatement(query)) {
        stmt.setInt(1, id);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            eventsList.add(mapResultSetToEvent(rs));
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return eventsList;
}

    public List<Events> getEventByClubId(int clubId){
        List<Events> eventsList = new ArrayList<>();
        String sql = """
                     SELECT eventId, eventName FROM Events where clubId = ?
                     """;
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setInt(1, clubId);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            Events event = new Events(rs.getInt("eventId"), rs.getString("eventName"));
            eventsList.add(event);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return eventsList;
}

    public Events getEventById(int eventId) {
        String sql = "SELECT * FROM Events WHERE eventId = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, eventId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToEvent(rs);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public Events getEventById1(int eventId) {
        Events event = null;
        String sql = "SELECT e.*, c.clubName "
                + "FROM Events e "
                + "JOIN Clubs c ON e.clubId = c.clubId "
                + "WHERE e.eventId = ?";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, eventId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                event = new Events();
                event.setEventId(rs.getInt("eventId"));
                event.setEventName(rs.getString("eventName"));
                event.setDescription(rs.getString("description"));
                event.setEventDate(rs.getDate("eventDate"));
                event.setLocation(rs.getString("location"));
                event.setClubId(rs.getInt("clubId"));
                event.setClubName(rs.getString("clubName"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return event;
    }

    public boolean insertEvent(Events event) {
        String sql = "INSERT INTO Events (eventName, description, eventDate, location, clubId) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            setEventStatement(stmt, event);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean updateEvent(Events event) {
        String sql = "UPDATE Events SET eventName = ?, description = ?, eventDate = ?, location = ?, clubId = ? WHERE eventId = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            setEventStatement(stmt, event);
            stmt.setInt(6, event.getEventId());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean deleteEvent(int eventId) {
        String sql = "DELETE FROM Events WHERE eventId = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, eventId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    private Events mapResultSetToEvent(ResultSet rs) throws SQLException {
    Events event = new Events();
    event.setEventId(rs.getInt("eventId"));
    event.setEventName(rs.getString("eventName"));
    event.setDescription(rs.getString("description"));
    event.setEventDate(rs.getDate("eventDate"));
    event.setLocation(rs.getString("location"));
    event.setClubId(rs.getInt("clubId"));
    event.setClubName(rs.getString("clubName")); // Thêm clubName
    event.setImage(rs.getString("image"));
    return event;
}
    private Events mapResultSetToEvent1(ResultSet rs) throws SQLException {
        return new Events(
                rs.getInt("eventId"),
                rs.getString("eventName"),
                rs.getString("description"),
                rs.getDate("eventDate"),
                rs.getString("location"),
                rs.getInt("clubId")
        );
    }

    private void setEventStatement(PreparedStatement stmt, Events event) throws SQLException {
        stmt.setString(1, event.getEventName());
        stmt.setString(2, event.getDescription());
        stmt.setDate(3, new java.sql.Date(event.getEventDate().getTime()));
        stmt.setString(4, event.getLocation());
        stmt.setInt(5, event.getClubId());
    }

    public List<Events> searchEventsByClubId(String keyword) {
        List<Events> events = new ArrayList<>();
        String sql = """
                     SELECT e.eventId, e.eventName, e.description, e.eventDate, e.location, e.clubId, c.clubName
                                                       FROM Events e LEFT JOIN Clubs c ON e.clubId = c.clubId 
                                                       WHERE e.eventName LIKE ? OR e.location LIKE ? OR c.clubName LIKE ? OR e.clubId LIKE ?
                     """;
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, "%" + keyword + "%");
            ps.setString(2, "%" + keyword + "%");
            ps.setString(3, "%" + keyword + "%");
            int eventId = -1;
            try {
                eventId = Integer.parseInt(keyword);
            } catch (NumberFormatException e) {

            }

            ps.setInt(4, eventId);

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Events event = new Events();
                event.setEventId(rs.getInt("eventId"));
                event.setEventName(rs.getString("eventName"));
                event.setDescription(rs.getString("description"));
                event.setEventDate(rs.getDate("eventDate"));
                event.setLocation(rs.getString("location"));
                event.setClubId(rs.getInt("clubId"));
                event.setClubName(rs.getString("clubName"));
                events.add(event);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return events;
    }

    private Events mapEvent(ResultSet rs) throws SQLException {
        Events event = new Events();
        event.setEventId(rs.getInt("eventId"));
        event.setEventName(rs.getString("eventName"));
        event.setDescription(rs.getString("description"));
        event.setEventDate(rs.getDate("eventDate"));
        event.setLocation(rs.getString("location"));
        event.setClubId(rs.getInt("clubId"));
        return event;
    }
    
    public static ArrayList<Events> getEvents(){
        DBContext db = DBContext.getInstance();
        ArrayList<Events> accounts = new ArrayList<Events>();
        try{
            String sql = "SELECT e.eventId, e.eventName, e.description, e.eventDate, e.location, e.clubId, e.image, c.clubName\n" +
"                                                       FROM Events e LEFT JOIN Clubs c ON e.clubId = c.clubId ";
            PreparedStatement statement = db.getConnection().prepareStatement(sql);
            ResultSet rs = statement.executeQuery();
            while(rs.next()){
                Events account = new Events(
                        rs.getInt("eventId"),
                        rs.getString("eventName"),
                        rs.getString("description"),
                        rs.getDate("eventDate"),
                        rs.getString("location"),
                        rs.getInt("clubId"),
                        rs.getString("eventDate"),
                        rs.getString("image")
                        
                );
                accounts.add(account);
            }
        }catch(Exception e){
            return null;
        }
        if(accounts.isEmpty()) return null;
        else return accounts;
    }
    
    public static Events addEvent(Events student) {
        DBContext db = DBContext.getInstance();
        int rs = 0;
        try {
            String sql = """
                           INSERT INTO Events (eventName, eventDate, location, description, clubId, image) VALUES (?, ?, ?, ?, ?, ?)
                                """;
            PreparedStatement statment = db.getConnection().prepareStatement(sql);
            statment.setString(1, student.getEventName());
            statment.setDate(2, (Date) student.getEventDate());
            statment.setString(3, student.getLocation());
            statment.setString(4, student.getDescription());
            statment.setInt(5, student.getClubId());
            statment.setString(6, student.getImage());
            rs = statment.executeUpdate();
        }catch (Exception e) {
        e.printStackTrace(); // In ra lỗi nếu có
        return null;
    }
        if(rs == 0) return null;
        else return student;
    }
    
    public static void main(String[] args) {
        ArrayList<Events> event = new ArrayList<>();
        EventDAO events = new EventDAO();
        event = (ArrayList<Events>) events.getEventsByClubId(2);
        for (Events eventa: event){
            System.out.println(eventa.getImage());
        }
    }
    
}
