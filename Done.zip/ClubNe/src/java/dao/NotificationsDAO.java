/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

/**
 *
 * @author A
 */

import model.Notification;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class NotificationsDAO {
  // Lấy danh sách thông báo gần đây
    public List<Notification> getRecentNotifications(int limit) {
        List<Notification> notifications = new ArrayList<>();
        String sql = "SELECT TOP (?) notificationId, title, message, createdAt FROM Notifications ORDER BY createdAt DESC";

        try (Connection conn = DBContext.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, limit);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Notification notification = new Notification(
                    rs.getInt("notificationId"),
                    rs.getString("title"),
                    rs.getString("message"),
                    rs.getTimestamp("createdAt")
                );
                notifications.add(notification);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return notifications;
    }

    // Lấy tổng số thông báo trong hệ thống
    public int getTotalNotificationCount() {
        int count = 0;
        String sql = "SELECT COUNT(*) FROM Notifications";

        try (Connection conn = DBContext.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                count = rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return count;
    }

    // Thêm một thông báo mới
    public void addNotification(String title, String message) {
        String sql = "INSERT INTO Notifications (title, message, createdAt) VALUES (?, ?, GETDATE())";

        try (Connection conn = DBContext.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, title);
            stmt.setString(2, message);
            stmt.executeUpdate();
            System.out.println("✅ Notification added: " + title);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    


// Xóa thông báo theo ID
public void deleteNotification(int notificationId) {
    String sql = "DELETE FROM Notifications WHERE notificationId = ?";
    try (Connection conn = DBContext.getInstance().getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setInt(1, notificationId);
        stmt.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

}
