package dao;

import model.EventParticipants;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Events;

public class EventParticipantDAO {
    private Connection conn;
    // Phương thức đăng ký người dùng vào sự kiện
    public void registerParticipant(int eventId, int userId, int statusId) throws SQLException {
        String sql = "INSERT INTO EventParticipants (eventId, userId, statusId) VALUES (?, ?, ?)";
        try (Connection connection = DBContext.getInstance().getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, eventId);
            preparedStatement.setInt(2, userId);
            preparedStatement.setInt(3, statusId);
            preparedStatement.executeUpdate();
        }
    }

    // Phương thức lấy danh sách tất cả người tham gia sự kiện
    public List<EventParticipants> getParticipantsByEvent(int eventId) throws SQLException {
        List<EventParticipants> participants = new ArrayList<>();
        String sql = "SELECT eventParticipantId, eventId, userId, statusId FROM EventParticipants WHERE eventId = ?";
        
        try (Connection connection = DBContext.getInstance().getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, eventId);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                EventParticipants participant = new EventParticipants(
                        resultSet.getInt("eventParticipantId"),
                        resultSet.getInt("eventId"),
                        resultSet.getInt("userId"),
                        resultSet.getInt("statusId")
                );
                participants.add(participant);
            }
        }
        return participants;
    }

    // Phương thức kiểm tra người dùng đã đăng ký sự kiện chưa
    public boolean isUserRegistered(int eventId, int userId) throws SQLException {
        String sql = "SELECT COUNT(*) FROM EventParticipants WHERE eventId = ? AND userId = ?";
        
        try (Connection connection = DBContext.getInstance().getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, eventId);
            preparedStatement.setInt(2, userId);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                return resultSet.getInt(1) > 0;
            }
        }
        return false;
    }

    // Phương thức xóa một người dùng khỏi sự kiện
    public void removeParticipant(int eventId, int userId) throws SQLException {
        String sql = "DELETE FROM EventParticipants WHERE eventId = ? AND userId = ?";
        
        try (Connection connection = DBContext.getInstance().getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, eventId);
            preparedStatement.setInt(2, userId);
            preparedStatement.executeUpdate();
        }
    }
    public EventParticipantDAO() {
        conn = DBContext.getInstance().getConnection();
    }
    
    public List<Events> getUserParticipationHistory(int userId) {
        List<Events> eventsList = new ArrayList<>();
        String sql = "SELECT e.eventId, e.eventName, e.eventDate, e.location, e.description, e.image " +
                     "FROM EventParticipants ep " +
                     "JOIN Events e ON ep.eventId = e.eventId " +
                     "WHERE ep.userId = ?";
        
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Events event = new Events();
                event.setEventId(rs.getInt("eventId"));
                event.setEventName(rs.getString("eventName"));
                event.setEventDate(rs.getDate("eventDate"));
                event.setLocation(rs.getString("location"));
                event.setDescription(rs.getString("description"));
                event.setImage(rs.getString("image"));
                eventsList.add(event);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return eventsList;
    }
}
