package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import model.Blogs;

public class BlogsDAO {
    private Connection connection;

    public BlogsDAO() {
        this.connection = DBContext.getInstance().getConnection();
    }

    public List<Blogs> getBlogsByClubId(int clubId) {
        List<Blogs> blogsList = new ArrayList<>();
        String query = "SELECT * FROM Blogs WHERE clubId = ?";

        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, clubId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Blogs blog = new Blogs(
                    rs.getInt("blogId"),
                    rs.getInt("clubId"),
                    rs.getString("title"),
                    rs.getString("decription"),  // Sử dụng đúng tên cột
                    rs.getString("location"),
                    rs.getDate("blogDate"),
                    rs.getString("image")
                );
                blogsList.add(blog);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return blogsList;
    }

    public List<Blogs> getBlogs() {
        List<Blogs> blogsList = new ArrayList<>();
        String query = "SELECT * FROM Blogs";

        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Blogs blog = new Blogs(
                    rs.getInt("blogId"),
                    rs.getInt("clubId"),
                    rs.getString("title"),
                    rs.getString("decription"),  // Sử dụng đúng tên cột
                    rs.getString("location"),
                    rs.getDate("blogDate"),
                    rs.getString("image")
                );
                blogsList.add(blog);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return blogsList;
    }

    public static Blogs addBlog(Blogs blog) {
        DBContext db = DBContext.getInstance();
        int rs = 0;
        try {
            String sql = "INSERT INTO Blogs (title, location, decription, clubId, blogDate, image) VALUES (?, ?, ?, ?, ?, ?)";
            try (PreparedStatement statement = db.getConnection().prepareStatement(sql)) {
                statement.setString(1, blog.getTitle());
                statement.setString(2, blog.getLocation());
                statement.setString(3, blog.getDecription());  // Sử dụng đúng tên cột
                statement.setInt(4, blog.getClubId());
                statement.setDate(5, (Date) blog.getBlogDate());
                statement.setString(6, blog.getImage());
                rs = statement.executeUpdate();
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        return (rs == 0) ? null : blog;
    }
}
