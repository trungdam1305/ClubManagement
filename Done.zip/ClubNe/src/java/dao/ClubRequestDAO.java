/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.ClubRequest;
/**
 *
 * @author A
 */
public class ClubRequestDAO {
    public static boolean addRequest(String username, String email, String password, int clubId) {
        try (Connection conn = DBContext.getInstance().getConnection()) {
            String sql = "INSERT INTO ClubRequest (username, email, password, clubId, status) VALUES (?, ?, ?, ?, 'Pending')";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, username);
            stmt.setString(2, email);
            stmt.setString(3, password);
            stmt.setInt(4, clubId);
            
            return stmt.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static List<ClubRequest> getPendingRequests() {
        List<ClubRequest> requests = new ArrayList<>();
        try (Connection conn = DBContext.getInstance().getConnection()) {
            String sql = "SELECT * FROM ClubRequest WHERE status = 'Pending'";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                requests.add(new ClubRequest(
                    rs.getInt("requestId"),
                    rs.getString("username"),
                    rs.getString("email"),
                    rs.getString("password"),
                    rs.getInt("clubId"),
                    rs.getString("status")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return requests;
    }

    public static ClubRequest getRequestById(int requestId) {
        try (Connection conn = DBContext.getInstance().getConnection()) {
            String sql = "SELECT * FROM ClubRequest WHERE requestId = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, requestId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return new ClubRequest(
                    rs.getInt("requestId"),
                    rs.getString("username"),
                    rs.getString("email"),
                    rs.getString("password"),
                    rs.getInt("clubId"),
                    rs.getString("status")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static boolean updateRequestStatus(int requestId, String status) {
        try (Connection conn = DBContext.getInstance().getConnection()) {
            String sql = "UPDATE ClubRequest SET status = ? WHERE requestId = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, status);
            stmt.setInt(2, requestId);
            return stmt.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public static List<ClubRequest> getRequestsByClubId(int clubId) {
    List<ClubRequest> requests = new ArrayList<>();
    try (Connection conn = DBContext.getInstance().getConnection()) {
        String sql = "SELECT * FROM ClubRequest WHERE clubId = ? AND status = 'Pending'";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setInt(1, clubId);
        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            requests.add(new ClubRequest(
                rs.getInt("requestId"),
                rs.getString("username"),
                rs.getString("email"),
                rs.getString("password"),
                rs.getInt("clubId"),
                rs.getString("status")
            ));
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return requests;
}
}
