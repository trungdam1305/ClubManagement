/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author A
 */
import java.sql.Timestamp;

public class Notification {
    private int notificationId;
    private String title;
    private String message;
    private Timestamp createdAt;

    public Notification(int notificationId, String title, String message, Timestamp createdAt) {
        this.notificationId = notificationId;
        this.title = title;
        this.message = message;
        this.createdAt = createdAt;
    }

    public int getNotificationId() { return notificationId; }
    public String getTitle() { return title; }
    public String getMessage() { return message; }
    public Timestamp getCreatedAt() { return createdAt; }
}

