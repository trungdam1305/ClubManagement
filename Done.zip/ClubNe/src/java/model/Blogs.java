/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.Date;

/**
 *
 * @author admin
 */
public class Blogs {
    private int blogId, clubId;
    private String title, decription, location;
    private Date blogDate;
    private String image;

    public Blogs() {
    }

    public Blogs(int blogId, int clubId, String title, String decription, String location, Date blogDate, String image) {
        this.blogId = blogId;
        this.clubId = clubId;
        this.title = title;
        this.decription = decription;
        this.location = location;
        this.blogDate = blogDate;
        this.image = image;
    }

    public int getBlogId() {
        return blogId;
    }

    public void setBlogId(int blogId) {
        this.blogId = blogId;
    }

    public int getClubId() {
        return clubId;
    }

    public void setClubId(int clubId) {
        this.clubId = clubId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDecription() {
        return decription;
    }

    public void setDecription(String decription) {
        this.decription = decription;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public Date getBlogDate() {
        return blogDate;
    }

    public void setBlogDate(Date blogDate) {
        this.blogDate = blogDate;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    @Override
    public String toString() {
        return "Blogs{" + "blogId=" + blogId + ", clubId=" + clubId + ", title=" + title + ", decription=" + decription + ", location=" + location + ", blogDate=" + blogDate + ", image=" + image + '}';
    }
    

}