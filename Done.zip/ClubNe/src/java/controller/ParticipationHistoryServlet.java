package controller;

import dao.EventParticipantDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.Events;
import model.Users;
import java.io.IOException;
import java.util.List;

public class ParticipationHistoryServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        Users currentUser = (Users) session.getAttribute("user");

        if (currentUser == null) {
            response.sendRedirect(request.getContextPath() + "/view/login.jsp");
            return;
        }

        EventParticipantDAO eventParticipantDAO = new EventParticipantDAO();
        List<Events> history = eventParticipantDAO.getUserParticipationHistory(currentUser.getUserId());

        request.setAttribute("history", history);
        // Sử dụng forward thay vì sendRedirect
        request.getRequestDispatcher("/view/event-history.jsp").forward(request, response);
    }
}
