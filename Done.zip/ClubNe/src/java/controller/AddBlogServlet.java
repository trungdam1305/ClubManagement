package controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.sql.Date;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;
import model.Blogs;
import dao.BlogsDAO;

@MultipartConfig(
    fileSizeThreshold = 1024 * 1024 * 2, // 2MB
    maxFileSize = 1024 * 1024 * 10,      // 10MB
    maxRequestSize = 1024 * 1024 * 50    // 50MB
)
public class AddBlogServlet extends HttpServlet {
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        HttpSession session = request.getSession();
        Integer clubId = (Integer) session.getAttribute("clubId");

        if (clubId == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String title = request.getParameter("title");
        String location = request.getParameter("location");
        String decription = request.getParameter("decription");  // Sử dụng đúng tên cột
        Date blogDate = Date.valueOf(request.getParameter("blogDate"));
        Part filePart = request.getPart("image");

        // Xử lý tải lên ảnh
        String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();
        String uploadDir = getServletContext().getRealPath("/img");

        File uploadPath = new File(uploadDir);
        if (!uploadPath.exists()) {
            uploadPath.mkdirs();
        }

        File file = new File(uploadDir, fileName);
        filePart.write(file.getAbsolutePath());

        // Lưu vào database
        Blogs blog = new Blogs();
        blog.setTitle(title);
        blog.setBlogDate(blogDate);
        blog.setLocation(location);
        blog.setDecription(decription);
        blog.setClubId(clubId);
        blog.setImage(fileName);

        BlogsDAO.addBlog(blog);
        response.sendRedirect(request.getContextPath() + "/view/main-view/home-blog.jsp");
    }
}
