/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import dao.AccountDAO;
import dao.ClubRequestDAO;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.List;
import model.ClubRequest;
import model.Users;
import utils.EmailService;

/**
 *
 * @author A
 */
public class AcceptRequestServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet AcceptRequestServlet</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet AcceptRequestServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Lấy clubId của Chairman từ session
        int chairmanClubId = (int) request.getSession().getAttribute("clubId");

        // Lấy danh sách yêu cầu của CLB mà Chairman đang quản lý
        List<ClubRequest> pendingRequests = ClubRequestDAO.getRequestsByClubId(chairmanClubId);

        // Gửi danh sách này sang JSP
        request.setAttribute("pendingRequests", pendingRequests);
        request.getRequestDispatcher("view/club-requests.jsp").forward(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int requestId = Integer.parseInt(request.getParameter("requestId"));
        String action = request.getParameter("action");

        // Lấy thông tin user từ ClubRequest
        ClubRequest requestInfo = ClubRequestDAO.getRequestById(requestId);
        
        if (requestInfo != null) {
            String email = requestInfo.getEmail();
            String subject = "Club Membership Request Update";
            String messageBody;

            if ("accept".equals(action)) {
                // Thêm user vào bảng Users
                Users newUser = new Users(
                    0, 
                    requestInfo.getUsername(),
                    requestInfo.getEmail(),
                    requestInfo.getPassword(),
                    5, // Role mặc định Member
                    requestInfo.getClubId()
                );

                Users addedUser = AccountDAO.addAccount(newUser);

                if (addedUser != null) {
                    ClubRequestDAO.updateRequestStatus(requestId, "Accepted");
                    messageBody = "Congratulations! Your request to join the club has been approved.";
                    EmailService.sendEmail(email, subject, messageBody);
                }
            } else if ("reject".equals(action)) {
                ClubRequestDAO.updateRequestStatus(requestId, "Rejected");
                messageBody = "Sorry, your request to join the club has been rejected.";
                EmailService.sendEmail(email, subject, messageBody);
            }
        }

        response.sendRedirect("view/chairman/chairman.jsp"); // Quay về trang chairman.jsp
    }

      

//    public static void main(String[] args) {
//        testAcceptRequest(1, "accept");
//    }
//
//    public static void testAcceptRequest(int requestId, String action) {
//        if ("accept".equals(action)) {
//            // Giả lập gọi DAO lấy dữ liệu từ database
//            ClubRequest requestInfo = ClubRequestDAO.getRequestById(requestId);
//
//            if (requestInfo != null) {
//                // Giả lập khởi tạo user từ requestInfo
//                Users newUser = new Users(
//                        0,
//                        requestInfo.getUsername(),
//                        requestInfo.getEmail(),
//                        requestInfo.getPassword(),
//                        5,
//                        requestInfo.getClubId()
//                );
//
//                System.out.println("User được tạo: " + newUser);
//            } else {
//                System.out.println("Không tìm thấy yêu cầu.");
//            }
//        } else {
//            System.out.println("Hành động không hợp lệ.");
//        }
//    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
