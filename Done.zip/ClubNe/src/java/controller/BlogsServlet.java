package controller;

import dao.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.*;

public class BlogsServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Blogs> blog = new ArrayList<>();
        HttpSession session = request.getSession();
        Users user = (Users) session.getAttribute("user");
        int id = user.getClubId();
        BlogsDAO member = new BlogsDAO();
        
        if (id == 1){
            blog = member.getBlogs();
                session.setAttribute("blog", blog);
            request.getRequestDispatcher("/view/main-view/admin/admin-home-blog.jsp").forward(request, response);

        }
        else if (id ==2){
        blog = member.getBlogsByClubId(id);
         session.setAttribute("blog", blog);
         request.getRequestDispatcher("/view/main-view/chairman/chairman-home-blog.jsp").forward(request, response);
        }
            // Lưu vào session thay vì request
        else if (id == 3){
            blog = member.getBlogsByClubId(id);
            session.setAttribute("blog", blog);
            request.getRequestDispatcher("/view/main-view/user/user-home-blog.jsp").forward(request, response);
        }


    }
}
