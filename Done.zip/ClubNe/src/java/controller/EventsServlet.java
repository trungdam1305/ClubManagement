package controller;

import dao.EventDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import model.Events;
import model.Users;


public class EventsServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        Users user = (Users) session.getAttribute("user");
        int id = user.getRoleId();
        int clubId = user.getClubId();
        List<Events> events = new ArrayList<>();
        EventDAO event = new EventDAO();
        session.setAttribute("clubId", clubId);
        if(id == 1){
            events = event.getEvents();
            request.getSession().setAttribute("events", events);
            request.getRequestDispatcher("/view/main-view/admin/home-event-admin.jsp").forward(request, response);
        }else if(id == 2){
            List<Events> event1 = new ArrayList<>();
            event1 =event.getEventsByClubId(clubId);
            session.setAttribute("events", event1);
            request.getRequestDispatcher("/view/main-view/chairman/home-event-chairman.jsp").forward(request, response);
        }else{
            events =event.getEventsByClubId(clubId);
            request.getSession().setAttribute("events", events);
            request.getRequestDispatcher("/view/main-view/user/home-event-user.jsp").forward(request, response);

        }
        
        // Lưu vào session thay vì request
        

        // Điều hướng về trang danh sách sự kiện
        
    }
}

