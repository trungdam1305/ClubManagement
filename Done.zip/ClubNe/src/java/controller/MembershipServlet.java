package controller;

import dao.EventDAO;
import dao.UsersDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.*;

public class MembershipServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Users> membership = new ArrayList<>();
        HttpSession session = request.getSession();
        Users user = (Users) session.getAttribute("user");
        int id = user.getClubId();
        UsersDAO member = new UsersDAO();
        if(user.isAdmin()){
            membership = member.getAllUsers();
            request.setAttribute("member", membership);
            request.getRequestDispatcher("/view/main-view/admin/admin-membership.jsp").forward(request, response);
        }
            
        else if (user.isChairman()){
            membership = member.getUsersByClubId(id);
            request.setAttribute("member", membership);
            request.getRequestDispatcher("/view/main-view/chairman/chairman-membership.jsp").forward(request, response);
        }
        else{
            membership = member.getUsersByClubId(id);
            request.setAttribute("member", membership);
            request.getRequestDispatcher("/view/main-view/user/user-membership.jsp").forward(request, response);
        }
        // Lưu vào session thay vì request
        request.setAttribute("member", membership);

        
    }
}
