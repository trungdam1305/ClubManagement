package controller;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;
import dao.DBContext;
import model.Users;

@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2, // 2MB
                 maxFileSize = 1024 * 1024 * 10,      // 10MB
                 maxRequestSize = 1024 * 1024 * 50)   // 50MB
public class UpdateProfileServlet extends HttpServlet {
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        Users user = (Users) session.getAttribute("user");
        if (user == null) {
            response.sendRedirect("view/login.jsp");
            return;
        }
        
        int userID = user.getUserId();
        String fullName = request.getParameter("fullName");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String password = request.getParameter("password");
        
        Part filePart = request.getPart("avatar");
        String fileName = (filePart != null && filePart.getSize() > 0) ? filePart.getSubmittedFileName() : "";
        
        if (!fileName.isEmpty()) {
            String uploadDir = getServletContext().getRealPath("/img");
            File fileSaveDir = new File(uploadDir);
            if (!fileSaveDir.exists()) {
                fileSaveDir.mkdirs();
            }
            filePart.write(uploadDir + File.separator + fileName);
        }
        
        try (Connection conn = DBContext.getInstance().getConnection()) {
            String currentPassword = getCurrentValue("Password", userID, conn);
            String currentAvatar = getCurrentValue("Avatar", userID, conn);
            
            String sql = "UPDATE Users SET FullName=?, Email=?, Phone=?" +
                         (!password.isEmpty() ? ", Password=?" : "") +
                         (!fileName.isEmpty() ? ", Avatar=?" : "") +
                         " WHERE UserID=?";
            
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, fullName);
            stmt.setString(2, email);
            stmt.setString(3, phone);
            
            int paramIndex = 4;
            if (!password.isEmpty()) {
                stmt.setString(paramIndex++, password);
            }
            if (!fileName.isEmpty()) {
                stmt.setString(paramIndex++, fileName);
            }
            stmt.setInt(paramIndex, userID);
            
            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                session.setAttribute("message", "Cập nhật thành công!");
                user.setFullName(fullName);
                user.setEmail(email);
                user.setPhone(phone);
                if (!fileName.isEmpty()) {
                    user.setAvatar(fileName);
                }
            } else {
                session.setAttribute("error", "Lỗi khi cập nhật.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            session.setAttribute("error", "Lỗi hệ thống.");
        }
        
        response.sendRedirect("view/profile.jsp");
    }
    
    private String getCurrentValue(String field, int userID, Connection conn) throws SQLException {
        String value = "";
        String sql = "SELECT " + field + " FROM Users WHERE UserID=?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userID);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    value = rs.getString(field);
                }
            }
        }
        return value;
    }
}