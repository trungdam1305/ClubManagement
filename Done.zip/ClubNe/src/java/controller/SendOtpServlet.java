package controller;

import dao.AccountDAO;
import dao.ClubDAO;
import dao.ClubRequestDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Properties;
import java.util.Random;
import jakarta.mail.Message;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;
import java.util.List;
import model.Clubs;
import model.Users;

public class SendOtpServlet extends HttpServlet {
    

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username = request.getParameter("user_su");
        String email = request.getParameter("email");
        String password = request.getParameter("password_su");
        String clubId = request.getParameter("club");

        System.out.println("DEBUG: Đăng ký - Username: " + username + ", Email: " + email + ", ClubId: " + clubId);
        
        // Kiểm tra dữ liệu hợp lệ
        if (username == null || email == null || password == null || clubId == null || clubId.isEmpty()) {
            request.setAttribute("errorMessage", "Vui lòng điền đầy đủ thông tin.");
            request.getRequestDispatcher("view/login.jsp").forward(request, response);
            return;
        }
        
        // Tạo mã OTP ngẫu nhiên
        Random rand = new Random();
        int otp = 100000 + rand.nextInt(900000);

        // Lưu OTP và thông tin đăng ký vào session
        HttpSession session = request.getSession();
        session.setAttribute("otp", otp);
        session.setAttribute("username", username);
        session.setAttribute("email", email);
        session.setAttribute("password", password);
        session.setAttribute("clubId", clubId);

        // Gửi email chứa OTP
        boolean emailSent = sendOtpEmail(email, otp);
        
        if (emailSent) {
            // Lưu yêu cầu vào bảng ClubRequest
            boolean requestSaved = ClubRequestDAO.addRequest(username, email, password, Integer.parseInt(clubId));

            if (requestSaved) {
                response.sendRedirect("view/authen-account/verify-email.jsp");
            } else {
                request.setAttribute("errorMessage", "Bạn cần đợi được accept!");
                request.getRequestDispatcher("view/login.jsp").forward(request, response);
            }
        } else {
            request.setAttribute("errorMessage", "Lỗi khi gửi email. Vui lòng thử lại.");
            request.getRequestDispatcher("view/login.jsp").forward(request, response);
        }

    }

//      public static void main(String[] args) {
//        ClubDAO c = new ClubDAO();
//    List<Clubs> clubs = c.getAllClubs();
//    for (Clubs club : clubs) {
//        System.out.println(club.getClubId() + " - " + club.getClubName());
//    }
//}
    private boolean sendOtpEmail(String recipientEmail, int otp) {
        final String senderEmail = "clubmanagementprj@gmail.com"; // Thay bằng email của bạn
        final String senderPassword = "tmll buci lscu wrde"; // Thay bằng mật khẩu ứng dụng

        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        Session session = Session.getInstance(props,
                new jakarta.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(senderEmail, senderPassword);
            }
        });

        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(senderEmail));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipientEmail));
            message.setSubject("OTP Code for authenticate gmail account");
            message.setText("Your OTP Code is: " + otp + ". This code is activated for 5 minutes.");

            Transport.send(message);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
