/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import dao.DBContext;
import dao.EventDAO;
import dao.*;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.util.Date;
import model.Events;
import java.util.List;
import java.sql.Connection;
import java.util.ArrayList;
import model.Users;

/**
 *
 * @author A
 */
public class EventManageServlet extends HttpServlet {

    private EventDAO eventsDAO;

    public EventManageServlet() {
        super();
        eventsDAO = new EventDAO();
    }

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet EventServlet</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet EventServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        HttpSession session = request.getSession();
        Users user = (Users) session.getAttribute("user");
        if ("edit".equals(action)) {
            int eventId = Integer.parseInt(request.getParameter("eventId"));
            Events event = eventsDAO.getEventById(eventId);
            request.setAttribute("event", event);
            request.getRequestDispatcher("/view/event-form.jsp").forward(request, response);
        } else if ("delete".equals(action)) {
            int eventId = Integer.parseInt(request.getParameter("eventId"));
            eventsDAO.deleteEvent(eventId);
            response.sendRedirect("Event");
        } else if ("view".equals(action)) {
            viewEvent(request, response);
        } else if ("search".equals(action)) {
            searchEvents(request, response);
        } else {
            List<Events> eventList = new ArrayList<>();
            if (user.isAdmin()){
                eventList = eventsDAO.getAllEvents();
            }
            else{
                eventList = eventsDAO.getEventsByClubId(user.getClubId());
            }
            request.setAttribute("events", eventList);
            request.getRequestDispatcher("/view/events.jsp").forward(request, response);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        String eventName = request.getParameter("eventName");
        String description = request.getParameter("description");
        String eventDateStr = request.getParameter("eventDate");
        String location = request.getParameter("location");
        int clubId = Integer.parseInt(request.getParameter("clubId"));

        Events event = new Events(0, eventName, description, java.sql.Date.valueOf(eventDateStr), location, clubId);

        if ("insert".equals(action)) {
            eventsDAO.insertEvent(event);
        } else if ("update".equals(action)) {
            event.setEventId(Integer.parseInt(request.getParameter("eventId")));
            eventsDAO.updateEvent(event);
        } 
        response.sendRedirect("Event");

    }

    private void viewEvent(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int eventId = Integer.parseInt(request.getParameter("eventId"));
        Events event = null;
        try {
            event = eventsDAO.getEventById1(eventId);
        } catch (Exception e) {
            System.out.println("Invalid event!");
        }

        if (event == null) {
            response.sendRedirect("events.jsp?error=Event not found");
            return;
        }

        request.setAttribute("event", event);
        request.getRequestDispatcher("view/event-view.jsp").forward(request, response);

    }

    private void searchEvents(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String keyword = request.getParameter("keyword");
        if (keyword == null) {
            keyword = "";
        }
        String eventIdStr = request.getParameter("eventId");
        Integer eventId = null;
        if (eventIdStr != null && !eventIdStr.isEmpty()) {
            try {
                eventId = Integer.parseInt(eventIdStr);
            } catch (NumberFormatException e) {
                eventId = null;
            }
        }
        List<Events> events = eventsDAO.searchEventsByClubId(keyword);
        request.setAttribute("events", events);
        request.getRequestDispatcher("/view/events.jsp").forward(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
