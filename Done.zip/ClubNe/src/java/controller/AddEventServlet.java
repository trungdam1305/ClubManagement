package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;
import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import model.Events;
import dao.EventDAO;
import java.sql.Date;
import java.time.LocalDate;
import model.Users;

@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2, // 2MB
                 maxFileSize = 1024 * 1024 * 10,      // 10MB
                 maxRequestSize = 1024 * 1024 * 50)   // 50MB
public class AddEventServlet extends HttpServlet {
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        
        HttpSession session = request.getSession();
        Integer clubId = (Integer) session.getAttribute("clubId");
        String clubName = (String) session.getAttribute("clubName");
        Users user = (Users) session.getAttribute("user");
                
        if (clubId == null || clubName == null) {
            response.sendRedirect("view/login.jsp");
            return;
        }
        
        String eventName = request.getParameter("eventName");
        Date eventDate = Date.valueOf(request.getParameter("eventDate")) ;
        String location = request.getParameter("location");
        String description = request.getParameter("description");
        
        Part filePart = request.getPart("image");
        String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();
        String uploadDir = getServletContext().getRealPath("/img");
        File uploadPath = new File(uploadDir);
        if (!uploadPath.exists()) {
            uploadPath.mkdirs();
        }
        
        File file = new File(uploadDir, fileName);
        filePart.write(file.getAbsolutePath());
        
        Events event = new Events();
        event.setEventName(eventName);
        event.setEventDate(eventDate);
        event.setLocation(location);
        event.setDescription(description);
        event.setClubId(clubId);
        event.setClubName(clubName);
        event.setImage(fileName);
        
        EventDAO eventDAO = new EventDAO();
        eventDAO.addEvent(event);
        
        if(user.isAdmin()){
            response.sendRedirect(request.getContextPath() +"/view/main-view/admin/home-event-admin.jsp");
        }
        if(user.isChairman()){
            response.sendRedirect(request.getContextPath() +"/view/main-view/chairman/home-event-chairman.jsp");
        }
        
    }
}