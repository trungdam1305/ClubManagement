/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import com.google.gson.Gson;
import dao.DBContext;
import dao.UsersDAO;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 *
 * @author A
 */
public class AttendanceRatioServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet AttendanceRatioServlet</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet AttendanceRatioServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        int eventId = Integer.parseInt(request.getParameter("eventId"));

        try (PrintWriter out = response.getWriter()) {
            Map<String, Integer> attendanceData = new HashMap<>();

            try (Connection conn = DBContext.getInstance().getConnection(); PreparedStatement stmt = conn.prepareStatement(
                    "SELECT statusId, COUNT(*) AS count FROM EventParticipants WHERE eventId = ? GROUP BY statusId"
            )) {
                stmt.setInt(1, eventId);
                ResultSet rs = stmt.executeQuery();

                attendanceData.put("present", 0);
                attendanceData.put("absent", 0);

                while (rs.next()) {
                    int statusId = rs.getInt("statusId");
                    int count = rs.getInt("count");

                    if (statusId == 1) {
                        attendanceData.put("present", count);
                    } else if (statusId == 2) {
                        attendanceData.put("absent", count);
                    }
                }
            }

            Gson gson = new Gson();
            out.print(gson.toJson(attendanceData));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         System.out.println("Received POST request for attendance update");

    // Kiểm tra xem có eventId hay không
    String eventIdStr = request.getParameter("eventId");
    if (eventIdStr == null || eventIdStr.isEmpty()) {
        System.out.println("ERROR: eventId is missing!");
        response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Event ID is required");
        return;
    }

    int eventId = Integer.parseInt(eventIdStr);
    UsersDAO usersDAO = new UsersDAO();

    // In danh sách tham số nhận được
    request.getParameterMap().forEach((key, value) -> {
        System.out.println("Parameter: " + key + " = " + String.join(",", value));
    });

    for (String paramName : request.getParameterMap().keySet()) {
        if (paramName.startsWith("status_")) {
            int userId = Integer.parseInt(paramName.substring(7));

            String statusStr = request.getParameter(paramName);
            if (statusStr == null || statusStr.isEmpty()) {
                System.out.println("ERROR: Missing status for userId: " + userId);
                continue; // Bỏ qua nếu không có dữ liệu
            }

            int statusId = Integer.parseInt(statusStr);
            System.out.println("Updating attendance - userId: " + userId + ", statusId: " + statusId);

            usersDAO.updateAttendance(eventId, userId, statusId);
        }
    }

    response.sendRedirect(request.getContextPath() + "/attendance?eventId=" + eventId);
}

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
